--
-- Mission11
--
-- @author  Stefan Geiger (mailto:sgeiger@giants.ch)
-- @date  12/03/08

Mission11 = {}

local Mission11_mt = Class(Mission11, BaseMission);

function Mission11:new()
    local instance = Mission11:superClass():new(Mission11_mt);

    instance.state = BaseMission.STATE_RUNNING;

    instance.playerStartX = 227;
    instance.playerStartY = 0.5;
    instance.playerStartZ = 98;
    instance.playerRotX = Utils.degToRad(5);
    instance.playerRotY = Utils.degToRad(39.7);

    --instance.preSimulateTime = 0;

    instance.obstacleCount = 0;

    instance.minTime = 7*60*1000+1;

    instance.frameCount = 0;

    instance.obstaclesLeft = 2;

    return instance;
end;

function Mission11:delete()

    --removeTrigger(getChild(self.missionMap, "farm_silo01_trigger1"));
    --removeTrigger(getChild(self.missionMap, "farm_silo01_trigger2"));
    --removeTrigger(getChild(self.missionMap, "farm_silo01_trigger3"));
    --removeTrigger(getChild(self.missionMap, "farm_silo01_trigger4"));

    Mission11:superClass().delete(self);
end;

function Mission11:triggerCallback(triggerId, otherId, onEnter, onLeave, onStay)

    local obj = self.obstacles[otherId];
    if obj ~= nil then

        if onEnter then
            --print("+");
            obj.inTriggerCount = obj.inTriggerCount + 1;
        else
            if onLeave then
                --print("-");
                obj.inTriggerCount = obj.inTriggerCount - 1;
            end;
        end;

    end;
    --print(triggerId, " ", otherId);
end;

function Mission11:load()

    self.environment = Environment:new("data/sky/sky_day_night.i3d", true, 6.5);

    self:loadMap("map01.i3d");

    self.missionMap = Mission11:superClass().loadMissionMap(self, "mission06/mission06.i3d");

    local markerId  = getChild(self.missionMap, "mission06_marker");
    setTranslation(markerId, 0, 0.02, 0);


    local treeParentId = getChild(self.rootNode, "forest2");
    if treeParentId ~= 0 then
        for i=1, 22 do
            local treeId = getChild(treeParentId, "maple01_tree_delete");
            if treeId ~= nil then
                delete(treeId);
            end;
        end;
    end;

    local triggerParentId = getChild(self.missionMap, "mission06_triggers");
    if triggerParentId ~= 0 then
        local numChildren = getNumOfChildren(triggerParentId);
        for i=0, numChildren-1 do
        --for i=numChildren-2, numChildren-1 do
            local id = getChildAt(triggerParentId, i);
            addTrigger(id, "triggerCallback", self);
        end;
    end;

    self.obstacles = {};
    local obstaclesParentId = getChild(self.missionMap, "obstacles");
    if obstaclesParentId ~= 0 then
        local numChildren = getNumOfChildren(obstaclesParentId);
        for i=0, numChildren-1 do
            local id = getChildAt(obstaclesParentId, i);
            self.obstacles[id] = {};
            self.obstacles[id].inTriggerCount = 0;

            --if i > 10 then
            --    delete(id);
            --end;

        end;
    end;

    self:loadTractor("data/vehicles/steerable/fendt/fendt936vario.xml", 220.8632, 0.5, 91.9929, Utils.degToRad(180));
    self:loadVehicle("data/vehicles/tools/plow01.xml", 220.8632, 0.5, 85, Utils.degToRad(0));

    Mission11:superClass().load(self);

    self.showHudMissionBase = true;


end

function Mission11:mouseEvent(posX, posY, isDown, isUp, button)
    Mission11:superClass().mouseEvent(self, posX, posY, isDown, isUp, button);
end;

function Mission11:keyEvent(unicode, sym, modifier, isDown)
    Mission11:superClass().keyEvent(self, unicode, sym, modifier, isDown);
end;

function Mission11:update(dt)
    Mission11:superClass().update(self, dt);

    if self.isRunning then

        if self.state == BaseMission.STATE_RUNNING then

            self.missionTime = self.missionTime + dt;

            if self.missionTime > self.minTime then
                self.state = BaseMission.STATE_FAILED;
                self.endTime = self.time;
            end;

            self.frameCount = self.frameCount + 1;
            self.obstacleCount = 0;
            for k,v in pairs(self.obstacles) do
                if v.inTriggerCount > 0 then
                    self.obstacleCount = self.obstacleCount + 1;
                end;
            end;

            if self.frameCount > 10 then

                if self.state ~= BaseMission.STATE_FINISHED and self.obstacleCount <= self.obstaclesLeft then
                    self.state = BaseMission.STATE_FINISHED;
                    self.endTime = self.missionTime;
                    self.endTimeStamp = self.time+self.endDelayTime;
                    Mission11:superClass().finishMission(self, self.endTime);
                end;

                if self.state ~= BaseMission.STATE_FAILED and self.missionTime > self.minTime then
                    self.state = BaseMission.STATE_FAILED;
                    self.endTime = self.missionTime;
                    self.endTimeStamp = self.time+self.endDelayTime;
                end;
            end;                
        end;

        if (self.state == BaseMission.STATE_FINISHED or self.state == BaseMission.STATE_FAILED) and self.endTimeStamp < self.time then
            OnInGameMenuMenu();
        end;
    end;
end;

function Mission11:draw()
    Mission11:superClass().draw(self);

    if self.isRunning then

        local time = self.minTime-self.missionTime;
        if time < 1*60*1000 then
            setTextColor(1.0, 0.0, 0.0, 1.0);
            if time < 0 then
                time = 0;
            end;
        end;
        Mission11:superClass().drawTime(self, true, time/(1000*60));
        setTextColor(1.0, 1.0, 1.0, 1.0);

        local count = self.obstacleCount-self.obstaclesLeft;
        if count < 0 then count = 0; end;

        setTextBold(true);
        renderText(0.05+0.075-0.049, 0.93-0.014, 0.06, string.format("Troncos de arvores %d", count));
        setTextBold(false);


        if self.state == BaseMission.STATE_FINISHED then
            RaceMission:superClass().drawMissionCompleted(self);
        end;

        if self.state == BaseMission.STATE_FAILED then
            RaceMission:superClass().drawMissionFailed(self);
        end;
    end;

end;