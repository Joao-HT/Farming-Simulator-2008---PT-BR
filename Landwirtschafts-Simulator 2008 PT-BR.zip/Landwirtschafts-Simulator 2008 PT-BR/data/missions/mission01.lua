Mission01 = {};

local Mission01_mt = Class(Mission01, RaceMission);

function Mission01:new()
    local instance = Mission01:superClass():new(Mission01_mt);

    instance.playerStartX = 731;
    instance.playerStartY = 6;
    instance.playerStartZ = -145;
    instance.playerRotX =Utils.degToRad(0);
    instance.playerRotY = Utils.degToRad(57.44);

    instance.numTriggers = 6;
    instance.triggerShapeCount = 5;

    instance.triggerPrefix = "mission01_trigger";

    return instance;
end;

function Mission01:delete()

    Mission01:superClass().delete(self);

end;

function Mission01:load()

    self.environment = Environment:new("data/sky/sky_day.i3d", false, 8);
    Mission01:superClass().loadMap(self, "map01.i3d");
    self.missionMap = Mission01:superClass().loadMissionMap(self, "mission01/mission01.i3d");

    --self.minTime = 110*1000+1;
    --self.minTime = 110*1000+1;

    self:loadTractor("data/vehicles/steerable/fendt/fendt716vario.xml", 726.2, 7.9, -149.7, Utils.degToRad(24-90));

    Mission01:superClass().load(self);

end

function Mission01:mouseEvent(posX, posY, isDown, isUp, button)
    Mission01:superClass().mouseEvent(self, posX, posY, isDown, isUp, button);
end;

function Mission01:keyEvent(unicode, sym, modifier, isDown)
    Mission01:superClass().keyEvent(self, unicode, sym, modifier, isDown);
end;

function Mission01:update(dt)
    Mission01:superClass().update(self, dt);
end;

function Mission01:draw()
    Mission01:superClass().draw(self);
end;

