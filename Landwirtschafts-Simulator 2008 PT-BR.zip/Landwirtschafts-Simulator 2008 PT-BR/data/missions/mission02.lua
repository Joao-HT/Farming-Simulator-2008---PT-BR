Mission02 = {};

local Mission02_mt = Class(Mission02, RaceMission);

function Mission02:new()
    local instance = Mission02:superClass():new(Mission02_mt);

    instance.playerStartX = -488;
    instance.playerStartY = -0.5;
    instance.playerStartZ = 146;
    instance.playerRotX = Utils.degToRad(0);
    instance.playerRotY = Utils.degToRad(-39);

    instance.numTriggers = 9;
    instance.triggerShapeCount = 1;
    instance.timeAttack = false;
    instance.doContactReport = true;
    instance.maxContacts = 5;

    instance.triggerPrefix = "mission02_trigger";

    instance.contactTransformGroupName = "strawbales";

    return instance;
end;

function Mission02:delete()

    Mission02:superClass().delete(self);

end;

function Mission02:load()

    self.environment = Environment:new("data/sky/sky_day.i3d", false, 8);
    Mission02:superClass().loadMap(self, "map01.i3d");
    self.missionMap = Mission02:superClass().loadMissionMap(self, "mission02/mission02.i3d");

    setRotation(self.environment.sunLightId, Utils.degToRad(-75), Utils.degToRad(-63), Utils.degToRad(25));

    local wheatId = getChild(self.terrainRootNode, "wheat");
    setEnableGrowth(wheatId, false);

    local cutter = self:loadVehicle("data/vehicles/cutters/fendt/fendtCutter6000.xml", -482, 0.5, 133.5+5, Utils.degToRad(0));
    local combine = self:loadVehicle("data/vehicles/steerable/fendt/fendt5270.xml", -482, 0, 138+5, Utils.degToRad(180));
    combine:attachCutter(cutter);
    table.insert(self.contactReportIds, combine.rootNode);
    table.insert(self.contactReportIds, cutter.rootNode);

    self.minTime = 10000000*1000;

    self.hitSound = createSample("hitSample");
    loadSample(self.hitSound, "data/maps/missions/mission02/hit.wav", false);

    Mission02:superClass().load(self);

end

function Mission02:mouseEvent(posX, posY, isDown, isUp, button)
    Mission02:superClass().mouseEvent(self, posX, posY, isDown, isUp, button);
end;

function Mission02:keyEvent(unicode, sym, modifier, isDown)
    Mission02:superClass().keyEvent(self, unicode, sym, modifier, isDown);
end;

function Mission02:update(dt)
    Mission02:superClass().update(self, dt);

    if self.currentVehicle ~= nil then
        self.currentVehicle.drawFillLevel = false;
    end;

end;

function Mission02:draw()
    Mission02:superClass().draw(self);
end;

