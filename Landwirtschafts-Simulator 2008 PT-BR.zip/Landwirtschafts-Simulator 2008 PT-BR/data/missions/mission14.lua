--
-- Mission14 (cleaning)
--
-- @author  Stefan Geiger (mailto:sgeiger@giants.ch)
-- @date  13/03/08

Mission14 = {}

local Mission14_mt = Class(Mission14, BaseMission);

function Mission14:new()
    local instance = Mission14:superClass():new(Mission14_mt);

    instance.state = BaseMission.STATE_INTRO;

    instance.playerStartX = 181.8;
    instance.playerStartY = 0.5;
    instance.playerStartZ = 184.5;

    instance.playerRotX = Utils.degToRad(0);
    instance.playerRotY = Utils.degToRad(-157.6);

    instance.vehiclesToClean = {};
    instance.minTime = 0;
    instance.lastNumCleaned = 0;

    return instance;
end;

function Mission14:delete()
    Mission14:superClass().delete(self);
end;

function Mission14:load()

    --self.renderTime = true;

    self.environment = Environment:new("data/sky/sky_day.i3d", false, 8);

    self:loadMap("map01.i3d");

    --local missionMarker = self:loadMissionMap("Mission07/mission07_fieldmarker.i3d");
    --translate(missionMarker, 0, 0.07, 0);

    self:loadVehicle("data/vehicles/steerable/fendt/fendt716vario.xml", 184, 0.5, 188.7, Utils.degToRad(180));

    table.insert(self.vehiclesToClean, self:loadVehicle("data/vehicles/tools/cultivator01.xml", 151.7, 0.5, 150.8, Utils.degToRad(90)));
    table.insert(self.vehiclesToClean, self:loadVehicle("data/vehicles/tools/sprayer01.xml", 221.25, 0.5, 218.8, Utils.degToRad(220)));
    table.insert(self.vehiclesToClean, self:loadVehicle("data/vehicles/tools/plough01.xml", 211.78, 0.5, 194, Utils.degToRad(0)));
    table.insert(self.vehiclesToClean, self:loadVehicle("data/vehicles/tools/plow01.xml", 144.9, 0.5, 207.5, Utils.degToRad(0)));
    table.insert(self.vehiclesToClean, self:loadVehicle("data/vehicles/tools/sowingMachine01.xml", 138.78, 0.5, 183.4, Utils.degToRad(-90)));
    table.insert(self.vehiclesToClean, self:loadVehicle("data/vehicles/tools/extraWeight01.xml", 190.56, 0.5, 152.3, Utils.degToRad(-90)));
    table.insert(self.vehiclesToClean, self:loadVehicle("data/vehicles/trailers/tipper01.xml", 202.14, 0.5, 146.7, Utils.degToRad(-90)));

    self.targetMinZ = 202.4928;
    self.targetMaxZ = 231.6559;
    self.targetMinX = 170.7;
    self.targetMaxX = 194.1309;

    --self.minTime = 10*60*1000;

    Mission14:superClass().load(self);

    self.showHudMissionBase = true;    

end

function Mission14:mouseEvent(posX, posY, isDown, isUp, button)
    Mission14:superClass().mouseEvent(self, posX, posY, isDown, isUp, button);
end;

function Mission14:keyEvent(unicode, sym, modifier, isDown)
    Mission14:superClass().keyEvent(self, unicode, sym, modifier, isDown);

    if self.state == BaseMission.STATE_INTRO and not self.controlPlayer then
        self.state = BaseMission.STATE_RUNNING;
    end;
end;

function Mission14:update(dt)
    Mission14:superClass().update(self, dt);

    if self.state == BaseMission.STATE_RUNNING then

        self.missionTime = self.missionTime + dt;

        if self.missionTime > self.minTime then
            self.state = BaseMission.STATE_FAILED;
            self.endTime = self.missionTime;
            self.endTimeStamp = self.time+self.endDelayTime;
        else

            self.lastNumCleaned = self:getNumCleanedVehicles();
            if self.lastNumCleaned == table.getn(self.vehiclesToClean) then
                self.state = BaseMission.STATE_FINISHED;
                self.endTime = self.missionTime;
                self.endTimeStamp = self.time+self.endDelayTime;
                FieldMission:superClass().finishMission(self, self.endTime);
            end;
        end;
    end;

    if (self.state == BaseMission.STATE_FINISHED or self.state == BaseMission.STATE_FAILED) and self.endTimeStamp < self.time then
        OnInGameMenuMenu();
    end;
end;

function Mission14:draw()
    Mission14:superClass().draw(self);

    if self.isRunning then

        local time = self.minTime-self.missionTime;
        if time < 10*1000 then
            setTextColor(1.0, 0.0, 0.0, 1.0);
            if time < 0 then
                time = 0;
            end;
        else
            setTextColor(1.0, 1.0, 1.0, 1.0);
        end;
        Mission14:superClass().drawTime(self, true, time/(1000*60));

        setTextBold(true);
        renderText(0.085-0.065, 0.93-0.014, 0.06, string.format("Implementos restantes: %d", table.getn(self.vehiclesToClean)-self.lastNumCleaned));
        setTextBold(false);

        if self.state == BaseMission.STATE_FINISHED then
            FieldMission:superClass().drawMissionCompleted(self);
        end;

        if self.state == BaseMission.STATE_FAILED then
            FieldMission:superClass().drawMissionFailed(self);
        end;
    end;

end;

function Mission14:getNumCleanedVehicles()

    local num = 0;
    for i=1, table.getn(self.vehiclesToClean) do
        local x,y,z = getWorldTranslation(self.vehiclesToClean[i].rootNode);
        if x >= self.targetMinX and x <= self.targetMaxX and
           z >= self.targetMinZ and z <= self.targetMaxZ then
            num = num+1;
        end;
    end;
    return num;
end;